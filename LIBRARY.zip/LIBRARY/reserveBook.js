const reservationDetailsDiv = document.getElementById("reservationDetails");

document.addEventListener("DOMContentLoaded", function () {
    fetchReservations();
});


reservationDetailsDiv.addEventListener("click", function (event) {
    if (event.target && event.target.classList.contains("checkout")) {
        const reservationId = event.target.getAttribute("data-id");
        const bookTitle = event.target.getAttribute("data-book");

        console.log(`Checkout clicked: ID=${reservationId}, Book=${bookTitle}`); 
        checkoutBook(reservationId, bookTitle);
    }
    else if (event.target && event.target.classList.contains("cancel")) {
        const reservationId = event.target.getAttribute("data-id");
        
        console.log(`Cancel clicked: ID=${reservationId}`); 
        cancelReservation(reservationId);
    }
});

document.getElementById("refreshReservations").addEventListener("click", fetchReservations);

function fetchReservations() {
    reservationDetailsDiv.innerHTML = "<p>Loading reservations...</p>";

    fetch("http://localhost:3000/api/reservations")
        .then(response => response.json())
        .then(reservations => {
            console.log("Fetched reservations:", reservations);

            reservationDetailsDiv.innerHTML = reservations.length
                ? reservations.map(reservation => `
                    <div class="reservation-card">
                        <h3>Book Title: ${reservation.book_title || "Unknown"}</h3>
                        <p><strong>ID:</strong> ${reservation.user_id}</p>
                         <p><strong>Name:</strong> ${reservation.name}</p>
                        <p><strong>Email:</strong> ${reservation.email}</p>
                        <p><strong>Reservation Date:</strong> ${formatDate(reservation.reservation_date)}</p>
                        <p><strong>Return Date:</strong> ${formatDate(reservation.check_out_date)}</p>
                        <p><strong>Status:</strong> ${reservation.status}</p>
                        <button class="checkout" data-id="${reservation.id}" data-book="${reservation.book_title || ""}"
                            ${reservation.status === "CheckedOut" ? "disabled" : ""}>
                            ${reservation.status === "CheckedOut" ? "Checked Out" : "Check Out"}
                        </button>
                        <button class="cancel" data-id="${reservation.id}" ${reservation.status === "CheckedOut" ? "disabled" : ""}>
                            Cancel
                        </button>
                    </div>
                `).join("")
                : "<p>No reservations found.</p>";
        })
        .catch(error => {
            console.error("Error fetching reservation data:", error);
            reservationDetailsDiv.innerHTML = "<p>Failed to load reservations.</p>";
        });
}

function formatDate(dateString) {
    const options = { year: "numeric", month: "long", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

function checkoutBook(reservationId, bookTitle) {
    fetch("http://localhost:3000/api/checkout", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ reservationId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`Checked out: ${bookTitle}`);
            fetchReservations();
        } else {
            alert(`Failed to check out book: ${data.message || "insufficient quantity of books"}`);
        }
    })
    .catch(error => {
        console.error("Error checking out book:", error);
        alert("An error occurred while checking out. Please try again.");
    });
}

function cancelReservation(reservationId) {
    fetch("http://localhost:3000/api/cancel", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ reservationId })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            alert("Reservation canceled successfully.");
            fetchReservations(); 
        } else {
            alert(`Failed to cancel reservation: ${data.error || "Unknown error"}`);
        }
    })
    .catch(error => {
        console.error("Error canceling reservation:", error);
        alert("An error occurred while canceling. Please try again.");
    });
}
