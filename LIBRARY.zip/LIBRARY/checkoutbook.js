const reservationDetailsDiv = document.getElementById("checkoutDetails");

document.addEventListener("DOMContentLoaded", function () {
    fetchReservations();
});

document.getElementById("refreshCheckout").addEventListener("click", fetchReservations);

async function fetchReservations() {
    reservationDetailsDiv.innerHTML = "<p>Loading reservations...</p>";

    try {
        const response = await fetch("http://localhost:3000/api/checkoutshow");
        const reservations = await response.json();

        console.log("Fetched reservations:", reservations);

        reservationDetailsDiv.innerHTML = reservations.length
            ? reservations.map(reservation => `
                <div class="reservation-card">
                    <h3>Book Title: ${reservation.book_title || "Unknown"}</h3>
                    <p><strong>ID:</strong> ${reservation.user_id}</p>
                    <p><strong>Name:</strong> ${reservation.name}</p>
                    <p><strong>Email:</strong> ${reservation.email}</p>
                    <p><strong>Reservation Date:</strong> ${formatDate(reservation.reservation_date)}</p>
                    <p><strong>Return Date:</strong> ${formatDate(reservation.check_out_date)}</p>
                    <button class="return" 
                        data-id="${reservation.id}" 
                        data-book="${reservation.book_title || ""}" 
                        data-email="${reservation.email}" 
                        data-name="${reservation.name}" 
                        data-reservation-date="${reservation.reservation_date}">
                        Return
                    </button>
                </div>
            `).join("")
            : "<p>No checkout found.</p>";

       
        document.querySelectorAll(".return").forEach(button => {
            button.addEventListener("click", async function () {
                const reservationId = this.getAttribute("data-id");
                const bookTitle = this.getAttribute("data-book");
                const userEmail = this.getAttribute("data-email");
                const userName = this.getAttribute("data-name");
                const reservationDate = this.getAttribute("data-reservation-date");
                
                console.log(`Return clicked: ID=${reservationId}, Book=${bookTitle}`);

                await sendReturnEmail(userEmail, userName, bookTitle, reservationDate);
                await returnBook(reservationId, bookTitle);
            });
        });

    } catch (error) {
        console.error("Error fetching reservation data:", error);
        reservationDetailsDiv.innerHTML = "<p>Failed to load reservations. Please try again later.</p>";
    }
}

async function sendReturnEmail(email, name, bookTitle, reservationDate) {
    const today = new Date().toISOString().split("T")[0];
    const returnDate = today;

    const emailParams = {
        to_email: email,
        to_name: name,
        book_title: bookTitle,
        reservation_date: reservationDate,
        return_date: returnDate
    };

    try {
        const response = await emailjs.send("service_ohcja9q", "template_3cefuyb", emailParams);
        console.log("✅ Email sent successfully!", response.status, response.text);
        alert("Return confirmed! A confirmation email has been sent.");
    } catch (error) {
        console.error("❌ Email sending failed:", error);
        alert("Failed to send return confirmation email.");
    }
}

function formatDate(dateString) {
    if (!dateString) return "Unknown"; // Handle missing dates
    const options = { year: "numeric", month: "long", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

async function returnBook(reservationId, bookTitle) {
    try {
        const response = await fetch("http://localhost:3000/api/return", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ reservationId })
        });

        const data = await response.json();

        if (data.success) {
            alert(`Successfully returned: ${bookTitle}`);
            await fetchReservations(); // Ensure UI updates after book return
        } else {
            alert("Error: Unable to return the book. Please try again.");
        }
    } catch (error) {
        console.error("Error returning book:", error);
        alert("Error: Unable to return the book due to a server issue.");
    }
}
