const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./library.db');

// Create tables
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS books (
      id INTEGER PRIMARY KEY,
      title TEXT,
      author TEXT,
      isbn TEXT,
      genre TEXT,
      year INTEGER,
      available BOOLEAN,
      quantity INTEGER,
      image TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS reservations (
      id INTEGER PRIMARY KEY,
      book_id INTEGER,
      user_id TEXT,
      name TEXT,
      email TEXT,
      reservation_date TEXT,
      check_out_date TEXT,
      status TEXT,
      FOREIGN KEY (book_id) REFERENCES books(id)
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);
});

module.exports = db;

db.serialize(() => {
    const books = [
        {
          id: 1,
          title: "The Vanishing Half",
          author: "Brit Bennett",
          isbn: "9780525536963",
          genre: "Fiction",
          year: 2020,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book1.jpg",
        },
        {
          id: 2,
          title: "Klara and the Sun",
          author: "Kazuo Ishiguro",
          isbn: "9780593318171",
          genre: "Science Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book2.jpg",
        },
        {
          id: 3,
          title: "The Midnight Library",
          author: "Matt Haig",
          isbn: "9780525559474",
          genre: "Fantasy",
          year: 2020,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book3.jpg",
        },
        {
          id: 4,
          title: "Malibu Rising",
          author: "Taylor Jenkins Reid",
          isbn: "9780593139442",
          genre: "Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book4.jpg",
        },
        {
          id: 5,
          title: "Project Hail Mary",
          author: "Andy Weir",
          isbn: "9780593135208",
          genre: "Science Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book5.jpg",
        },
        {
          id: 6,
          title: "The Last House on Needless Street",
          author: "Catriona Ward",
          isbn: "9781250815204",
          genre: "Thriller",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book6.jpg",
        },
        {
          id: 7,
          title: "The Four Winds",
          author: "Kristin Hannah",
          isbn: "9781250178602",
          genre: "Historical Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book7.jpg",
        },
        {
          id: 8,
          title: "The Invisible Life of Addie LaRue",
          author: "V.E. Schwab",
          isbn: "9780765387561",
          genre: "Fantasy",
          year: 2020,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book8.jpg",
        },
        {
          id: 9,
          title: "The Paper Palace",
          author: "Miranda Cowley Heller",
          isbn: "9780593133761",
          genre: "Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book9.jpg",
        },
        {
          id: 10,
          title: "The Song of Achilles",
          author: "Madeline Miller",
          isbn: "9780062060624",
          genre: "Mythology",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book10.jpg",
        },
        {
          id: 11,
          title: "Beautiful World, Where Are You",
          author: "Sally Rooney",
          isbn: "9780571365420",
          genre: "Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book11.jpg",
        },
        {
          id: 12,
          title: "The Last Thing He Told Me",
          author: "Laura Dave",
          isbn: "9781501171345",
          genre: "Thriller",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 5,
          image: "./Books/book12.jpg",
        },
        {
          id: 13,
          title: "The Guest List",
          author: "Emma Cline",
          isbn: "9780812998603",
          genre: "Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book13.jpg",
        },
        {
          id: 14,
          title: "The Maidens",
          author: "Alex Michaelides",
          isbn: "9781250304440",
          genre: "Thriller",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book14.jpg",
        },
        {
          id: 15,
          title: "The Lincoln Highway",
          author: "Amor Towles",
          isbn: "9780735222359",
          genre: "Historical Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book15.jpg",
        },
        {
          id: 16,
          title: "Cloud Cuckoo Land",
          author: "Anthony Doerr",
          isbn: "9781982168438",
          genre: "Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book16.jpg",
        },
        {
          id: 17,
          title: "The Book of Form and Emptiness",
          author: "Ruth Ozeki",
          isbn: "9780593653960",
          genre: "Fiction",
          year: 2022,
          available: true,
          showDetails: false,
          quantity:10,
          image: "./Books/book17.jpg",
        },
        {
          id: 18,
          title: "Lessons in Chemistry",
          author: "Bonnie Garmus",
          isbn: "9780594801012",
          genre: "Fiction",
          year: 2022,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book18.jpg",
        },
        {
          id: 19,
          title: "The Island of Missing Trees",
          author: "Elif Shafak",
          isbn: "9781635574440",
          genre: "Fiction",
          year: 2021,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book19.jpg",
        },
        {
          id: 20,
          title: "The Seven Husbands of Evelyn Hugo",
          author: "Taylor Jenkins Reid",
          isbn: "9781501139239",
          genre: "Historical Fiction",
          year: 2017,
          available: true,
          showDetails: false,
          quantity: 10,
          image: "./Books/book20.jpg",
        },
        {
            id: 21,
            title: "The Paris Apartment",
            author: "Lucy Foley",
            isbn: "9780063033652",
            genre: "Thriller",
            year: 2022,
            available: true,
            showDetails: false,
            quantity: 10,
            image: "./Books/book21.jpg",
          },
          {
            id: 22,
            title: "The Night Circus",
            author: "Erin Morgenstern",
            isbn: "9780385534635",
            genre: "Fantasy",
            year: 2011,
            available: true,
            showDetails: false,
            quantity: 10,
            image: "./Books/book22.jpg",
          },
          {
            id: 23,
            title: "A Gentle Reminder",
            author: "Bianca Sparacino",
            isbn: "9789355438485",
            genre: "Personal Development",
            year: 2021,
            available: true,
            showDetails: false,
            quantity: 10,
            image: "./Books/book23.jpg",
          },
          {
            id: 24,
            title: "The Chain",
            author: "Adrian McKinty",
            isbn: "9780316499680",
            genre: "Thriller",
            year: 2019,
            available: true,
            showDetails: false,
            quantity: 10,
            image: "./Books/book24.jpg",
          },
          {
            id: 25,
            title: "A Court of Thorns and Roses",
            author: "Sarah J. Maas",
            isbn: "9781635575569",
            genre: "Fantasy",
            year: 2015,
            available: true,
            showDetails: false,
            quantity: 10,
            image: "./Books/book25.jpg",
          },
          { id: 26, title: "Love in the Time of Cholera", author: "Gabriel G. Garcia", isbn: "9781400034680", genre: "Fiction", year: 2003, available: true, showDetails: false,quantity: 10, image: "./Books/book26.jpg" },
          { id: 27, title: "Tiny Beautiful Things: Advice from Dear Sugar", author: "Cheryl Strayed", isbn: "9780593685211", genre: "Personal Development", year: 2012, available: true, showDetails: false,quantity: 10, image: "./Books/book27.jpg" },
          { id: 28, title: "Normal People", author: "Sally Rooney", isbn: "9781984822178", genre: "Fiction", year: 2019, available: true, showDetails: false,quantity: 10, image: "./Books/book28.jpg" },
          { id: 29, title: "All the Light We Cannot See", author: "Anthony Doerr", isbn: "9781476746586", genre: "Historical Fiction", year: 2014, available: true, showDetails: false,quantity: 10, image: "./Books/book29.jpg" },
          { id: 30, title: "Anxious People", author: "Fredrik Backman", isbn: "9781982169633", genre: "Mystery", year: 2019, available: true, showDetails: false,quantity: 10, image: "./Books/book30.jpg" }
      ];
      
      const admins = [
        {
          id: 1,
          username: "eduardocojuangco1@gmail.com",
          password: "JACE0128"
        },
        {
          id: 2,
          username: "j.quiroben28@gmail.com",
          password: "justine28"
        },
      ];
  
      const query = 'INSERT INTO books (title, author, isbn, genre, year, available,quantity, image) VALUES (?, ?, ?, ?, ?, ?, ?,?)';
      books.forEach((book) => {
        const { title, author, isbn, genre, year, available,quantity, image } = book;
        db.run(query, [title, author, isbn, genre, year, available,quantity, image], (err) => {
          if (err) {
            console.error(`Error inserting book "${title}":`, err.message);
          } else {
            console.log(`Book "${title}" inserted successfully.`);
          }
        });
      });

      const queryAcc = 'INSERT INTO admins (id,username,password) VALUES (?, ?, ?)';
      admins.forEach((admins) => {
        const { id,username,password } = admins;
        db.run(queryAcc, [id,username,password], (err) => {
          if (err) {
            console.error(`Error login user "${username}":`, err.message);
          } else {
            console.log(`User "${username}" inserted successfully.`);
          }
        });
      });
      
  }); 
  