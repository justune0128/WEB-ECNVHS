const express = require('express');
const cors = require('cors');
const db = require('./database');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());



app.get('/api/books', (req, res) => {
  const query = 'SELECT * FROM books';
  db.all(query, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});



app.post('/api/reserve', (req, res) => {
  const { bookId, studentId, name, email, reservationDate,checkOutDate } = req.body;
  const status = 'Reserved';

  if (!bookId || !studentId || !name || !email || !reservationDate||!checkOutDate) {
      return res.status(400).json({ error: 'All reservation fields are required.' });
  }

  db.serialize(() => {
      db.run('BEGIN TRANSACTION');

     
      db.get('SELECT quantity FROM books WHERE id = ?', [bookId], (err, row) => {
          if (err) {
              console.error('Error querying book:', err.message);
              db.run('ROLLBACK');
              return res.status(500).json({ error: 'Database error.' });
          }

          if (!row) {
              db.run('ROLLBACK');
              return res.status(404).json({ error: 'Book not found.' });
          }

          if (row.quantity <= 0) {
              db.run('ROLLBACK');
              return res.status(400).json({ error: 'Book is out of stock and cannot be reserved.' });
          }

              
          const insertQuery = `
          INSERT INTO reservations (book_id, user_id, name, email, reservation_date, check_out_date, status)
          VALUES (?, ?, ?, ?, ?, ?, ?)
      `;
              db.run(insertQuery, [bookId, studentId, name, email, reservationDate,checkOutDate, status], function (err) {
                  if (err) {
                      console.error('Error inserting reservation:', err.message);
                      db.run('ROLLBACK');
                      return res.status(500).json({ error: 'Failed to create reservation.' });
                  }

                  db.run('COMMIT', (err) => {
                      if (err) {
                          console.error('Error committing transaction:', err.message);
                          db.run('ROLLBACK');
                          return res.status(500).json({ error: 'Failed to commit reservation.' });
                      }

                      res.status(200).json({ message: 'Reservation confirmed.' });
                  });
              });
          });
      });
  });


  

  app.post('/api/admin', (req, res) => {
    const { username, password } = req.body;

    db.get('SELECT * FROM admins WHERE username = ?', [username], (err, row) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (!row) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

       
        if (row.password !== password) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        res.json({ message: 'Login successful', admin: row });
    });
});


app.get('/api/reservations', (req, res) => {
    const { page = 1, limit = 100 } = req.query;
    const offset = (page - 1) * limit;

    db.all(
        `SELECT r.id, b.title AS book_title, r.user_id, r.name, r.email, 
                r.reservation_date, r.check_out_date, r.status 
         FROM reservations r 
         JOIN books b ON r.book_id = b.id 
         WHERE r.status = 'Reserved' 
         LIMIT ${parseInt(limit)} OFFSET ${parseInt(offset)}`,
        (err, rows) => {
            if (err) {
                console.error('Error fetching reservations:', err.message);
                return res.status(500).json({ error: 'Database error.' });
            }

            res.json(rows);
        }
    );
});


  app.get('/api/checkoutshow', (req, res) => {
    const { page = 1, limit = 100 } = req.query;
    const offset = (page - 1) * limit;
    
    db.all('SELECT r.id, b.title AS book_title, r.name,r.user_id, r.email, r.reservation_date,r.check_out_date, r.status ' + 
      'FROM reservations r JOIN books b ON r.book_id = b.id ' + 
      'WHERE r.status = ? LIMIT ? OFFSET ?', ['CheckedOut', limit, offset], (err, rows) => {
        if (err) {
            console.error('Error fetching reservations:', err.message);
            return res.status(500).json({ error: 'Database error.' });
        }

        res.json(rows);
    });
});

app.post("/api/checkout", (req, res) => {
  const { reservationId } = req.body;

 
  db.get(
      `SELECT quantity FROM books WHERE id = (SELECT book_id FROM reservations WHERE id = ?)`,

      [reservationId],
      (err, row) => {
          if (err) {
              console.error("Error retrieving book quantity:", err.message);
              return res.status(500).json({ success: false, error: "Database error." });
          }

          if (!row || row.quantity <= 0) {
              
              db.run(
                  `UPDATE books SET available = 0 WHERE id = (SELECT book_id FROM reservations WHERE id = ?)`,
                  [reservationId],
                  function (err) {
                      if (err) {
                          console.error("Error updating book availability:", err.message);
                          return res.status(500).json({ success: false, error: "Failed to update book availability." });
                      }

                      return res.status(400).json({ success: false, error: "Insufficient book quantity." });
                  }
              );
              return;
          }

          
          db.run(
              "UPDATE reservations SET status = 'CheckedOut' WHERE id = ?",
              [reservationId],
              function (err) {
                  if (err) {
                      console.error("Error updating reservation status:", err.message);
                      return res.status(500).json({ success: false, error: "Failed to update reservation status." });
                  }

                 
                  db.run(
                      `UPDATE books SET quantity = quantity - 1 WHERE id = (SELECT book_id FROM reservations WHERE id = ?)`,

                      [reservationId],
                      function (err) {
                          if (err) {
                              console.error("Error updating book quantity:", err.message);
                              return res.status(500).json({ success: false, error: "Database error." });
                          }

                          db.run(
                              `UPDATE books SET available = 0 WHERE id = (SELECT book_id FROM reservations WHERE id = ?) AND quantity <= 0`,
                              [reservationId],
                              function (err) {
                                  if (err) {
                                      console.error("Error updating book availability:", err.message);
                                      return res.status(500).json({ success: false, error: "Failed to update book availability." });
                                  }

                                  res.json({ success: true, message: "Book checked out successfully." });
                              }
                          );
                      }
                  );
              }
          );
      }
  );
});


app.post("/api/return", (req, res) => {
  const { reservationId } = req.body;

  db.serialize(() => {
     
      db.run("BEGIN TRANSACTION", (err) => {
          if (err) {
              console.error("Error starting transaction:", err.message);
              return res.status(500).json({ success: false, error: "Failed to begin transaction." });
          }

         
          db.get("SELECT book_id FROM reservations WHERE id = ?", [reservationId], (err, row) => {
              if (err || !row) {
                  console.error("Error finding reservation:", err?.message || "Not found");
                  return db.run("ROLLBACK", () => {
                      res.status(500).json({ success: false, error: "Reservation not found." });
                  });
              }

              const bookId = row.book_id;

            
              db.run("UPDATE books SET quantity = quantity + 1 WHERE id = ?", [bookId], function (updateErr) {
                  if (updateErr) {
                      console.error("Error updating book quantity:", updateErr.message);
                      return db.run("ROLLBACK", () => {
                          res.status(500).json({ success: false, error: "Failed to update book quantity." });
                      });
                  }

                 
                  db.get("SELECT quantity FROM books WHERE id = ?", [bookId], (checkErr, checkRow) => {
                      if (checkErr) {
                          console.error("Error checking book quantity:", checkErr.message);
                          return db.run("ROLLBACK", () => {
                              res.status(500).json({ success: false, error: "Failed to check book quantity." });
                          });
                      }

                     
                      if (checkRow.quantity > 0) {
                          db.run("UPDATE books SET available = 1 WHERE id = ?", [bookId], (availErr) => {
                              if (availErr) {
                                  console.error("Error updating book availability:", availErr.message);
                                  return db.run("ROLLBACK", () => {
                                      res.status(500).json({ success: false, error: "Failed to update book availability." });
                                  });
                              }
                          });
                      }

                     
                      db.run("DELETE FROM reservations WHERE id = ?", [reservationId], function (deleteErr) {
                          if (deleteErr) {
                              console.error("Error deleting reservation:", deleteErr.message);
                              return db.run("ROLLBACK", () => {
                                  res.status(500).json({ success: false, error: "Failed to delete reservation." });
                              });
                          }

                         
                          db.run("COMMIT", (commitErr) => {
                              if (commitErr) {
                                  console.error("Error committing transaction:", commitErr.message);
                                  return res.status(500).json({ success: false, error: "Failed to commit transaction." });
                              }

                              
                              res.json({ success: true });
                          });
                      });
                  });
              });
          });
      });
  });
});

app.post("/api/cancel", (req, res) => {
    const { reservationId } = req.body;
  
    db.serialize(() => {
        
        db.run("BEGIN TRANSACTION", (err) => {
            if (err) {
                console.error("Error starting transaction:", err.message);
                return res.status(500).json({ success: false, error: "Failed to begin transaction." });
            }

            
            db.run("DELETE FROM reservations WHERE id = ?", [reservationId], function (deleteErr) {
                if (deleteErr) {
                    console.error("Error deleting reservation:", deleteErr.message);
                    return db.run("ROLLBACK", () => {
                        res.status(500).json({ success: false, error: "Failed to delete reservation." });
                    });
                }

                
                db.run("COMMIT", (commitErr) => {
                    if (commitErr) {
                        console.error("Error committing transaction:", commitErr.message);
                        return res.status(500).json({ success: false, error: "Failed to commit transaction." });
                    }

                   
                    res.json({ success: true });
                });
            });
        });
    });
});





app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
