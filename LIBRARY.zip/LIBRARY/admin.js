fetch('http://localhost:3000/api/books')
    .then(response => response.json())
    .then(books => {
      const bookDetailsDiv = document.getElementById('bookDetails');
      books.forEach(book => {
        const bookDiv = document.createElement('div');
        bookDiv.classList.add('book');

        const availability = book.quantity > 0 ? 'Available' : 'Not Available';

        bookDiv.innerHTML = `
          <img src="${book.image}" alt="${book.title}" class="book-cover">
          <div class="book-info">
            <h2 class="book-title">${book.title}</h2>
            <p class="book-author">Author: ${book.author}</p>
            <p class="ISBN">ISBN: ${book.isbn}</p>
            <p class="book-year">Genre: ${book.year}</p>
            <p class="book-quantity">Quantity: ${book.quantity}</p>
            <p class="status">Status: ${availability}</p>
          </div>
        `;
        bookDetailsDiv.appendChild(bookDiv);
      });
    })
    .catch(error => console.error('Error fetching books:', error));